def sortedSquares(self, A):
    return list(sorted([a ** 2 for a in A]))